public enum States {
    MENU,
    PLAYING,
    PLANTSLIST,
    ZOMBIESLIST,
    HELP,
    PLAY,
    GAMEOVER;
}
