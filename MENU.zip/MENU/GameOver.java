import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;


public class GameOver implements ScreenMethod {

    private Game game;

	private MyButton  b1, b2;
	private BufferedImage[] GameOver = new BufferedImage[1];
	private BufferedImage selectedGameOver = null;

	public GameOver(Game game) {
		this.game = game;

		initGameOver();
		initButtons();

	}

	private void initGameOver() {
		GameOver[0] = getImage("DECK-INVENTORY");

	}

	private void initButtons() {

		int w = 70;
		int h = 70;
		int x = 46;
		int y = 117;
		int xOffset = w + 60;
		// int yOffset = h + 25;

		b1 = new MyButton("1", x, y, w, h);
		b2 = new MyButton("2", x + xOffset - 35, y, w, h);
	}

	@Override
	public void render(Graphics g) {
		drawButtons(g);
		drawBackground(g);
		drawZombieDesc(g);

	}

	private void drawZombieDesc(Graphics g) {
		g.drawImage(selectedGameOver, 0, 0, null);
	}

	private void drawBackground(Graphics g) {
        BufferedImage img = getImage("GAMEOVER");

        g.drawImage(img, 0, 0, null);
    }

	private BufferedImage getImage(String index) {
		BufferedImage img = null;
		InputStream is = getClass().getResourceAsStream(index + ".png");

		try {
			img = ImageIO.read(is);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		return img;
	}

    private void drawButtons(Graphics g) {

		b1.draw(g);
		b2.draw(g);

	}

	@Override
	public void mouseClicked(int x, int y) {
        if (b1.getBounds().contains(x, y)) {
			selectedGameOver = GameOver[0];
        }
        if (b2.getBounds().contains(x, y)) {
			game.setStates(States.MENU);
        }
	}

	@Override
	public void mouseMoved(int x, int y) {
		b1.setMouseOver(false);
		b2.setMouseOver(false);

		if (b1.getBounds().contains(x, y)) {
			b1.setMouseOver(true);
		}
		if (b2.getBounds().contains(x, y)) {
			b2.setMouseOver(true);
		}

	}

	@Override
	public void mousePressed(int x, int y) {

		if (b1.getBounds().contains(x, y)) {
			b1.setMousePressed(true);
		}
		if (b2.getBounds().contains(x, y)) {
			b2.setMousePressed(true);
		}

	}

	@Override
	public void mouseReleased(int x, int y) {
		resetButtons();
	}

	private void resetButtons() {
		b1.resetBooleans();
		b2.resetBooleans();
	}

}